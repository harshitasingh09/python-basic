def check_age(age):
    if age < 1 or age > 120:
        raise ValueError("Age must be between 1 and 120")

try:
    age_input = int(input("Enter your age: "))
    check_age(age_input)
    print(f"Age {age_input} successfully validated.")
except ValueError as e:
    print(f"Error: {e}")